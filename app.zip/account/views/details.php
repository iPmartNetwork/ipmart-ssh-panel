<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "format_traffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryDays         = getArrayValue($userInfo, "expiry_days");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "format_consumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$sshPort            = getArrayValue($arrayConfig, "ssh_port", "");
$udpPort            = getArrayValue($arrayConfig, "udp_port", "");
$host               = getArrayValue($arrayConfig, "host", "");

$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز دیگر";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}

$values = [
    [
        "label" => "نام کاربری",
        "value" => $username,
    ],
    [
        "label" => "رمز عبور",
        "value" => $password,
    ],
    [
        "label" => "HOST",
        "value" => $host
    ],
    [
        "label" => "پورت SSH",
        "value" => $sshPort
    ],
    [
        "label" => "پورت UPD",
        "value" => $udpPort
    ],
    [
        "label" =>  "ترافیک",
        "value" => $traffic,
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" =>  "تاریخ شروع",
        "value" => $startJD,
    ],
    [
        "label" =>  "مدت زمان",
        "value" => $diffrenceDate,
    ],
    [
        "label" => "تاریخ پایان",
        "value" => $endDateJD,
    ],
    [
        "label" =>  "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" =>  "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
];

?>

<div class="row justify-content-center">
    <div class="col-lg-7">

        <div class="card shadow-lg border-0">
            <div class="card-header border-bottom-0 py-3">

                اطلاعات پروفایل شما
            </div>
            <div class="card-body">
                <?php if (!empty($settings["logo_url"])) { ?>
                    <div class="text-center">
                        <img src="<?= $settings["logo_url"] ?>" width="100" />
                    </div>
                <?php } ?>
                <?php if (!empty($settings["welecom_text"])) { ?>
                    <div class="text-center border-bottom py-2"><?= $settings["welecom_text"] ?></div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-8 border-end">
                        <?php
                        foreach ($values as  $key => $item) {
                            $label = $item["label"];
                            $value = $item["value"];
                            $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3";
                            if ($key < count($values) - 1) {
                                $class .= " border-bottom";
                            }
                        ?>
                            <div class="<?= $class ?>">
                                <span class="text-muted small"><?= $label ?></span>
                                <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="col-lg-4 text-center">
                        <div class="d-flex h-100 justify-content-around flex-column">
                            <div class="mb-3">
                                <p class="small">جهت استفاده در برنامه Netmod اندروید تصویر زیر را اسکن کنید</p>
                                <img class="m-auto" src="<?= $netmodQrUrl ?>" />
                            </div>
							<div class="d-flex flex-row align-items-center justify-content-between py-2 px-3 so-topboarder so-bt">
							<div class="so-align mohidde" <?= $mobileiphone ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">دانلود برنامه ها</span>
								<div class="so-softiconbox">
									<a target="_blank" class="so-softicons" href="<?= baseUrl("https://apps.apple.com/gb/app/npv-tunnel/id1629465476") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/NapsternetV.png") ?>" width="72"><span class="text-muted so-info so-widt so-softicontitle">NapsternetV</span></a>
									<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width='72'><span class="text-muted so-info so-widt so-softicontitle">Streisand</span></a>
								</div>
                            <div>
														<div class="so-iconsbox">
								<div class="so-btns so-btns-ssh">
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna1')">لینک v2Ray<p class="so-widt" id="matna1">https://panel.ipmart.online:2087/sub/<?= $usersinfo ?></p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna2')">لینک SSH<p class="so-widt" id="matna2">ssh://<?= $username ?>:<?= $password ?>@<?= $host ?>:<?= $sshPort ?>#ipmart-<?= ucfirst($username); ?></p></button>	
								</div>
								<div class="so-btns so-btns-vray">
									<!--?= print_r($jsonfilee) ?-->
									<!--?= $userUUID ?-->
									<!--?= var_dump($userUUID) ?-->
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna10')">HamrahAval<p class="so-widt so-widt-vray" id="matna10" style="font-size:0!important;width:100px!important;">vless://<?= $useruuid ?>@xmci.ipmart.online:443?type=grpc&serviceName=%40ipmart&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=panel.ipmart.online#ipmart-<?= ucfirst($username); ?>  HamrahAval</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna11')">Irancell<p class="so-widt so-widt-vray" id="matna11" style="font-size:0!important;width:100px!important;">vless://<?= $useruuid ?>@xmtn.ipmart.online:443?type=grpc&serviceName=%40ipmart&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=panel.ipmart.online#ipmart-<?= ucfirst($username); ?>  Irancell</p></button>
                                <?php if (!empty($settings["support_url"])) { ?>
                                    <a target="_blank" class="btn btn-primary d-block" href="<?= $settings["support_url"] ?>">ارتباط با پشتیبانی</a>
																	<div class="so-textBoxpanel">
									<span class="text-muted fw-bold so-info so-widt so-topboarder so-textBoxTitr">اخبار</span>
									<div class="so-textBox">
										...
									</div>
								</div>
							</div>
                                <?php } ?>
                                <a class="btn btn-danger mt-2 d-block" href="<?= baseUrl("") ?>">خروج</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>