<div class="card">
    <div class="card-body">
        <p>برای وارد کردن کاربران از دراگون بکاپ گرفته و متن فایل را در باکس زیر پیست کنید</ح>
            <hr />
        <form>
            <textarea rows="10" class="form-control text-end dir-ltr" placeholder="test • 983 • 2 • 284 DIAS"></textarea>
            <button>افزودن کاربران</button>
        </form>
    </div>

</div>

<script></script>