<?php
/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

if (!defined('PATH')) die();

/**
 * Uploads Config
 */
$configs['upload']['dir'] = PATH_ASSETS . DS . 'uploads';
$configs['upload']['temp'] = PATH_TEMP;
$configs['upload']['url'] = $configs['url'] . 'assets/uploads/';

?>
